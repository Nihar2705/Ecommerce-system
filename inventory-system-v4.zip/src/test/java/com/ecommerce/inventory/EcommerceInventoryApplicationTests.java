package com.ecommerce.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceInventoryApplicationTests {

    @Test
    void contextLoads() {
    }
}
